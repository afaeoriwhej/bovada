import React from 'react';

interface TagButtonProps {
  label: string;
}

const TagButton: React.FC<TagButtonProps> = ({ label }) => {
  return (
    <button className="rounded-full border border-gray-300 px-4 py-2 text-sm text-gray-800 transition hover:bg-gray-100">
      {label}
    </button>
  );
};

export default TagButton;