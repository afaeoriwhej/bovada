import React from 'react';
import { Info } from 'lucide-react';

interface DownloadStatsProps {
  rating: number;
  reviewCount: number;
  fileSize: string;
  ageRating: string;
  downloadCount: string;
}

const DownloadStats: React.FC<DownloadStatsProps> = ({
  rating,
  reviewCount,
  fileSize,
  ageRating,
  downloadCount,
}) => {
  return (
    <div className="flex items-center justify-between py-2">
      <div className="flex items-center gap-1">
        <span className="font-bold">{rating.toFixed(1)}</span>
        <span className="text-gray-700">★</span>
        <div className="flex items-center gap-1 text-sm text-gray-700">
          <span>{reviewCount.toLocaleString()} reviews</span>
          <Info size={14} className="cursor-pointer text-gray-500" />
        </div>
      </div>

      <div className="h-6 border-l border-gray-300"></div>

      <div className="flex flex-col items-center">
        <span className="text-sm font-bold">{fileSize}</span>
        <span className="text-xs text-gray-600">MB</span>
      </div>

      <div className="h-6 border-l border-gray-300"></div>

      <div className="flex flex-col items-center rounded-md bg-gray-100 px-2 py-1">
        <span className="text-sm font-bold">{ageRating}</span>
        <span className="text-xs text-gray-600">+</span>
      </div>

      <div className="h-6 border-l border-gray-300"></div>

      <div className="flex flex-col items-center">
        <span className="text-sm font-bold">{downloadCount}</span>
        <span className="text-xs text-gray-600">Downloads</span>
      </div>
    </div>
  );
};

export default DownloadStats;