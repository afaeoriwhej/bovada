import React from 'react';
import { BadgeCheck } from 'lucide-react';

interface AppHeaderProps {
  appName: string;
  developerName: string;
  appLogo: string;
  isVerified?: boolean;
  hasAds?: boolean;
}

const AppHeader: React.FC<AppHeaderProps> = ({
  appName,
  developerName,
  appLogo,
  isVerified = false,
  hasAds = false,
}) => {
  return (
    <div className="flex items-start gap-4 pb-4">
      <div className="h-16 w-16 flex-shrink-0 overflow-hidden rounded-xl bg-red-600">
        <img
          src={appLogo}
          alt={`${appName} logo`}
          className="h-full w-full object-cover"
          onError={(e) => {
            const target = e.target as HTMLImageElement;
            target.src = "https://via.placeholder.com/64";
          }}
        />
      </div>
      
      <div className="flex flex-col">
        <h1 className="text-xl font-bold text-gray-900">{appName}</h1>
        <div className="flex items-center gap-1">
          <span className="text-sm text-blue-600">{developerName}</span>
          {isVerified && (
            <BadgeCheck size={16} className="text-blue-600" />
          )}
        </div>
        {hasAds && (
          <span className="mt-1 text-xs text-gray-600">Contains ads</span>
        )}
      </div>
    </div>
  );
};

export default AppHeader;