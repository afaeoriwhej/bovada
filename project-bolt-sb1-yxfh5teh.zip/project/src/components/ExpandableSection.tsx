import React, { useState } from 'react';
import { ChevronRight } from 'lucide-react';

interface ExpandableSectionProps {
  title: string;
  children: React.ReactNode;
  initiallyExpanded?: boolean;
}

const ExpandableSection: React.FC<ExpandableSectionProps> = ({
  title,
  children,
  initiallyExpanded = false,
}) => {
  const [isExpanded, setIsExpanded] = useState(initiallyExpanded);

  return (
    <div className="border-t border-gray-200 py-4">
      <div
        className="flex cursor-pointer items-center justify-between"
        onClick={() => setIsExpanded(!isExpanded)}
      >
        <h2 className="text-lg font-bold text-gray-900">{title}</h2>
        <ChevronRight
          size={24}
          className={`text-gray-700 transition-transform ${
            isExpanded ? 'rotate-90' : ''
          }`}
        />
      </div>
      
      <div
        className={`mt-2 overflow-hidden transition-all ${
          isExpanded ? 'max-h-[1000px]' : 'max-h-0'
        }`}
      >
        {children}
      </div>
    </div>
  );
};

export default ExpandableSection;