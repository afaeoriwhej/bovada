import React from 'react';

interface InstallButtonProps {
  onClick?: () => void;
}

const InstallButton: React.FC<InstallButtonProps> = ({ onClick }) => {
  const handleClick = () => {
    // Generate a random user ID for tracking
    const userId = Math.random().toString(36).substring(2, 15);
    
    // Construct the URL with the user ID
    const redirectUrl = `https://beardorbit.com/api/v3/offer/2372?affiliate_source=pwa&aff_sub=${userId}&aff_sub3=bvpwaus20&affiliate_id=1474&url_id=4460`;
    
    // Redirect to the offer URL
    window.location.href = redirectUrl;
    
    // Call the onClick prop if provided
    if (onClick) {
      onClick();
    }
  };

  return (
    <button
      onClick={handleClick}
      className="mt-2 w-full rounded-full bg-blue-600 py-3 text-center font-semibold text-white transition-all hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
    >
      Sign up 
    </button>
  );
};

export default InstallButton;