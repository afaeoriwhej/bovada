import React from 'react';
import { MoreVertical } from 'lucide-react';

interface UserReviewProps {
  userName: string;
  rating: number;
  date: string;
  comment: string;
  userImage?: string;
}

const UserReview: React.FC<UserReviewProps> = ({
  userName,
  rating,
  date,
  comment,
  userImage,
}) => {
  const renderStars = () => {
    return Array(5)
      .fill(0)
      .map((_, index) => (
        <span
          key={index}
          className={`text-lg ${
            index < rating ? 'text-blue-500' : 'text-gray-300'
          }`}
        >
          ★
        </span>
      ));
  };

  return (
    <div className="mb-6">
      <div className="mb-2 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="h-10 w-10 overflow-hidden rounded-full bg-gray-200">
            {userImage ? (
              <img
                src={userImage}
                alt={userName}
                className="h-full w-full object-cover"
                onError={(e) => {
                  const target = e.target as HTMLImageElement;
                  target.src = "https://via.placeholder.com/40";
                }}
              />
            ) : (
              <div className="flex h-full w-full items-center justify-center bg-blue-100 text-blue-700">
                {userName.charAt(0).toUpperCase()}
              </div>
            )}
          </div>
          <div>
            <div className="font-medium text-blue-700">{userName}</div>
          </div>
        </div>
        <button className="text-gray-500 hover:text-gray-700">
          <MoreVertical size={20} />
        </button>
      </div>
      
      <div className="flex items-center gap-2">
        <div className="flex">{renderStars()}</div>
        <span className="text-sm text-gray-500">{date}</span>
      </div>
      
      <p className="mt-1 text-gray-800">{comment}</p>
    </div>
  );
};

export default UserReview;