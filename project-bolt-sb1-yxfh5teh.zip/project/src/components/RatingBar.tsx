import React from 'react';

interface RatingBarProps {
  starNumber: number;
  percentage: number;
}

const RatingBar: React.FC<RatingBarProps> = ({ starNumber, percentage }) => {
  return (
    <div className="flex items-center gap-2">
      <span className="w-3 text-sm">{starNumber}</span>
      <div className="h-2 w-full overflow-hidden rounded-full bg-gray-200">
        <div
          className="h-full rounded-full bg-blue-500"
          style={{ width: `${percentage}%` }}
        ></div>
      </div>
    </div>
  );
};

export default RatingBar;