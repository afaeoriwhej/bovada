import React from 'react';

interface ScreenshotGalleryProps {
  screenshots: string[];
}

const ScreenshotGallery: React.FC<ScreenshotGalleryProps> = ({ screenshots }) => {
  return (
    <div className="mt-4 flex gap-2 overflow-x-auto pb-2">
      {screenshots.map((screenshot, index) => (
        <div
          key={index}
          className="flex-shrink-0 overflow-hidden rounded-xl"
          style={{ width: '180px', height: '180px' }}
        >
          <img
            src={screenshot}
            alt={`App screenshot ${index + 1}`}
            className="h-full w-full object-cover"
            onError={(e) => {
              const target = e.target as HTMLImageElement;
              target.src = "https://via.placeholder.com/180";
            }}
          />
        </div>
      ))}
    </div>
  );
};

export default ScreenshotGallery;