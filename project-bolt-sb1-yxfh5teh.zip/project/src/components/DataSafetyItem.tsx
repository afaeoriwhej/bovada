import React from 'react';
import { Share, Lock, Trash, DivideIcon as LucideIcon } from 'lucide-react';

type DataSafetyItemType = 'collect' | 'share' | 'encrypt' | 'delete';

interface DataSafetyItemProps {
  type: DataSafetyItemType;
  description: string;
  details?: string;
}

const DataSafetyItem: React.FC<DataSafetyItemProps> = ({
  type,
  description,
  details,
}) => {
  const getIcon = (): LucideIcon => {
    switch (type) {
      case 'collect':
      case 'share':
        return Share;
      case 'encrypt':
        return Lock;
      case 'delete':
        return Trash;
      default:
        return Share;
    }
  };

  const Icon = getIcon();
  
  const getTitle = (): string => {
    switch (type) {
      case 'collect':
        return 'This app may collect these data types';
      case 'share':
        return 'This app may share these data types with third parties';
      case 'encrypt':
        return 'Data is encrypted in transit';
      case 'delete':
        return 'You can request that data be deleted';
      default:
        return '';
    }
  };

  return (
    <div className="mb-4 flex items-start gap-4">
      <div className="mt-1 flex h-8 w-8 items-center justify-center">
        <Icon size={20} className="text-gray-700" />
      </div>
      
      <div className="flex-1">
        <p className="font-medium text-gray-900">{getTitle()}</p>
        {description && <p className="text-sm text-gray-700">{description}</p>}
        {details && <p className="text-xs text-gray-600">{details}</p>}
      </div>
    </div>
  );
};

export default DataSafetyItem;