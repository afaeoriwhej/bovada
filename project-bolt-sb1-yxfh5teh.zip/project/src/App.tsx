import React from 'react';
import AppHeader from './components/AppHeader';
import DownloadStats from './components/DownloadStats';
import InstallButton from './components/InstallButton';
import ScreenshotGallery from './components/ScreenshotGallery';
import ExpandableSection from './components/ExpandableSection';
import TagButton from './components/TagButton';
import DataSafetyItem from './components/DataSafetyItem';
import RatingBar from './components/RatingBar';
import UserReview from './components/UserReview';

function App() {
  // Mock data that would typically come from an API
  const appData = {
    appName: 'Bovada Casino',
    developerName: 'FiveStar Games - Slots and Casino',
    isVerified: true,
    hasAds: true,
    rating: 4.3,
    reviewCount: 173900,
    fileSize: '3',
    ageRating: '17',
    downloadCount: '1,000+',
    appLogo: 'https://placehold.co/64/FF0000/FFFFFF?text=B',
    screenshots: [
      'https://images.pexels.com/photos/1871508/pexels-photo-1871508.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      'https://images.pexels.com/photos/3279695/pexels-photo-3279695.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    ],
    description: 'Slots And Casino™ is a top-tier mobile application designed for gambling enthusiasts who crave the thrill of casino games right at their fingertips. This app brings the vibrant and exhilarating atmosphere of a casino directly to your mobile device, offering a wide array of slot games, table games, and other casino favorites that you can enjoy anytime, anywhere.',
    tags: ['Mobile casino', 'Roulette King', 'Fast payouts', 'Bonuses and promotions'],
    dataSafety: {
      collect: {
        description: 'Personal info and Device or other IDs',
      },
      share: {
        description: 'App activity and Device or other IDs',
      },
      encrypt: {
        description: '',
      },
      delete: {
        description: '',
      },
    },
    ratingDistribution: [
      { stars: 5, percentage: 75 },
      { stars: 4, percentage: 15 },
      { stars: 3, percentage: 5 },
      { stars: 2, percentage: 3 },
      { stars: 1, percentage: 2 },
    ],
    reviews: [
      {
        userName: 'Korey28',
        rating: 4,
        date: '9/5/2025',
        comment: 'I\'ve been using this app for a few weeks, and the experience has been fantastic. The user interface is smooth, and I\'ve seen consistent earnings. It\'s definitely worth trying if you\'re interested in this field.',
        userImage: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      },
    ],
  };

  return (
    <div className="mx-auto max-w-2xl bg-white px-4 py-6">
      <AppHeader
        appName={appData.appName}
        developerName={appData.developerName}
        appLogo={appData.appLogo}
        isVerified={appData.isVerified}
        hasAds={appData.hasAds}
      />
      
      <DownloadStats
        rating={appData.rating}
        reviewCount={appData.reviewCount}
        fileSize={appData.fileSize}
        ageRating={appData.ageRating}
        downloadCount={appData.downloadCount}
      />
      
      <InstallButton onClick={() => alert('Install button clicked')} />
      
      <ScreenshotGallery screenshots={appData.screenshots} />
      
      <ExpandableSection title="About this game">
        <p className="text-gray-800">{appData.description}</p>
        <div className="mt-4 flex flex-wrap gap-2">
          {appData.tags.map((tag, index) => (
            <TagButton key={index} label={tag} />
          ))}
        </div>
      </ExpandableSection>
      
      <ExpandableSection title="Data safety">
        <p className="mb-4 text-sm text-gray-700">
          To manage your safety, it's important to understand how developers collect and share your
          data. Data privacy and security practices may vary based on your use, region, and age. The
          information below is provided by the developer and may change in the future.
        </p>
        
        <DataSafetyItem
          type="collect"
          description={appData.dataSafety.collect.description}
        />
        <DataSafetyItem
          type="share"
          description={appData.dataSafety.share.description}
        />
        <DataSafetyItem type="encrypt" description={appData.dataSafety.encrypt.description} />
        <DataSafetyItem type="delete" description={appData.dataSafety.delete.description} />
        
        <button className="text-sm text-blue-600">See details</button>
      </ExpandableSection>
      
      <ExpandableSection title="Ratings and reviews">
        <div className="mb-4 flex items-center gap-6">
          <div className="flex flex-col items-center">
            <span className="text-5xl font-bold">{appData.rating}</span>
            <div className="flex text-lg text-gray-400">
              {'★★★★★'.split('').map((_, i) => (
                <span
                  key={i}
                  className={i < Math.floor(appData.rating) ? 'text-blue-500' : ''}
                >
                  ★
                </span>
              ))}
            </div>
            <span className="text-sm text-gray-600">{appData.reviewCount.toLocaleString()}</span>
          </div>
          
          <div className="flex-1 space-y-1">
            {appData.ratingDistribution.map((item) => (
              <RatingBar
                key={item.stars}
                starNumber={item.stars}
                percentage={item.percentage}
              />
            ))}
          </div>
        </div>
        
        <div className="mt-6">
          <p className="mb-2 text-sm text-gray-600">Ratings and reviews are verified</p>
          {appData.reviews.map((review, index) => (
            <UserReview
              key={index}
              userName={review.userName}
              rating={review.rating}
              date={review.date}
              comment={review.comment}
              userImage={review.userImage}
            />
          ))}
        </div>
      </ExpandableSection>
    </div>
  );
}

export default App;